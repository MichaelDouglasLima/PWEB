// module.exports = function (app) {
//     app.get('/informacao/professores', function (req, res) {
//         res.render('informacao/professores');
//     });
// }

module.exports = function (app) {
    app.get('/informacao/professores', function (req, res) {
        const sql = require('mssql/msnodesqlv8');
        const sqlConfig = {
            user: 'BD2211041',
            password: 'MichaelBD99',
            database: 'lp2', //Na FATEC, utilizar o database BD ou LP8
            server: 'APOLO',//Caso o nome tenha uma instância, colocar duas
            //barras, ex: ‘DESKTOP\\SQLSERVER.Na FATEC, utilizar o ip: 192.168.1.6 no nome do servidor
        }

       
        async function getProfessores() {
            try {
            const pool = await sql.connect(sqlConfig);
           
            const results = await pool.request().query('SELECT * from PROFESSORES')
           
            res.render('informacao/professores',{profs : results.recordset});
           
            } catch (err) {
            console.log(err)
            }
            }
            getProfessores();
            });
           } 
           